import gymnasium as gym
import random
import math
import ast
import csv, json, os
import numpy as np
import multiprocessing as mp
import random

# Pour exécuter sans ouvrir de fenêtre graphique
os.environ["SDL_VIDEODRIVER"] = "dummy"
N_WORKERS = 3  # Nombre de workers à lancer

# --- Paramètres ---
N_EPISODES = 100
MAX_STEPS = 300
ALPHA = 0.1
GAMMA = 0.95
EPSILON = np.linspace(0.5, 0.2, N_WORKERS)  # Different epsilon for each worker
BASE_SEED = 42  # seed de départ
Q_TABLE_FILE = "Save_folder/Merged_table/tot_q_table.csv"
Q_TABLE_FOLDER = "Save_folder/worker"
SCORES_FILE = "Save_folder/worker"

def count_lines(filename=SCORES_FILE):
    with open(filename, newline="") as f:
        reader = csv.reader(f)
        next(reader)  # skip header
        line_count = sum(1 for _ in reader)
    return line_count

def get_worker_paths(worker_id):
    folder = f"Save_folder/worker{worker_id}"
    os.makedirs(folder, exist_ok=True)
    return {
        "q_table": folder + "\q_table.csv",
        "scores": folder + "\scores.csv"
    }


# --- Initialisation ---
ACTIONS = [
    np.array([0.0, 1.0, 0.0]),   # accélérer
    np.array([0.0, 0.0, 0.8]),   # frein
    np.array([-1.0, 0.5, 0.0]),  # tourner gauche + accélérer
    np.array([1.0, 0.5, 0.0]),   # tourner droite + accélérer
]

# --- Fonctions utilitaires de Q-learning ---
def discretize_state(state, precision=4):
    return tuple(round(float(x), precision) for x in state)

def save_q_table(Q, filename):
    with open(filename, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["state", "action", "value"])
        for state, actions in Q.items():
            # convert state to plain Python list (no numpy types)
            state_list = [int(x) if (hasattr(x, "dtype") or isinstance(x, (np.integer, np.floating))) else x for x in state]
            state_json = json.dumps(state_list)
            for a, val in enumerate(actions):
                writer.writerow([state_json, a, float(val)])

def load_q_table(chemin):
    Q = {}
    if os.path.exists(chemin):
        with open(chemin, "r", newline="") as f:
            reader = csv.DictReader(f)
            for row in reader:
                state_list = json.loads(row["state"])
                state = tuple(state_list)
                action = int(row["action"])
                value = float(row["value"])
                if state not in Q:
                    # allocate array sized to your action count (example 5)
                    Q[state] = np.zeros(len(ACTIONS))  # ACTIONS doit être défini avant
                Q[state][action] = value
    return Q

def append_score_to_csv(episode, total_score, q_size, filename=SCORES_FILE):
    file_exists = os.path.exists(filename)
    with open(filename, "a", newline="") as f:
        writer = csv.writer(f)
        if not file_exists:
            writer.writerow(["episode", "total_score", "q_size"])
        writer.writerow([episode, total_score, q_size])

def is_road_pixel(px):
    r, g, b = int(px[0]), int(px[1]), int(px[2])
    if px.max() <= 1.0:
        r, g, b = int(r*255), int(g*255), int(b*255)
    mean = (r+g+b)/3
    if abs(g-r) > 40 and abs(g-b) > 40 and mean < 180:
        return True
    return False

def get_ray_distances(obs, car_angle=0.0, num_rays=7, max_distance=60, step=3, cone=np.pi/2):
    """
    Calcule les distances à l'herbe pour plusieurs rayons autour de la voiture.
    Utilise un pas large pour aller vite, puis affine localement lorsqu'on touche l'herbe.
    """
    h, w, _ = obs.shape
    cx, cy = w // 2, h // 2  # centre (voiture)
    ray_angles = np.linspace(-cone, cone, num_rays)
    distances = []

    for a in ray_angles:
        angle = car_angle + a
        dx, dy = math.cos(angle), math.sin(angle)
        distance = max_distance

        début = 0
        fin = max_distance
        while début < fin: 
            d = (début + fin) // 2
            x = int(cx + d * dx)
            y = int(cy - d * dy)  # y diminue vers le haut de l'image
            if x < 0 or x >= w or y < 0 or y >= h:
                distance = d
                fin = d - 1
                continue
            px = obs[y, x, :3]
            if is_road_pixel(px):
                début = d + 1
            else:
                fin = d - 1

        distances.append(distance / max_distance)  # normalisation [0,1]

    return np.array(distances)

# --- Boucle principale ---
def run_worker(worker_id):
    try:
        paths = get_worker_paths(worker_id)
        Q = load_q_table(paths["q_table"])
        epsilon = EPSILON[worker_id - 1]

        seed = BASE_SEED + worker_id
        random.seed(seed)
        np.random.seed(seed)
        env = gym.make("CarRacing-v3", render_mode=None)
        env.reset(seed=seed)

        for ep in range(N_EPISODES):
            obs, _ = env.reset()
            total_reward = 0

            for step in range(MAX_STEPS):
                car = env.unwrapped.car
                car_angle = car.hull.angle
                state = get_ray_distances(obs, car_angle)
                #print(state) # test de ma fonction ray distances
                state_key = discretize_state(state, 1)
                #print(state_key) # test de ma fonction ray distances

                if state_key not in Q:
                    Q[state_key] = np.zeros(len(ACTIONS))

                # epsilon-greedy
                if (random.randint(0, 999) / 1000) < epsilon:
                    action_id = np.random.randint(len(ACTIONS))
                else:
                    action_id = np.argmax(Q[state_key])

                action = ACTIONS[action_id]
                obs, reward, terminated, truncated, _ = env.step(action)
                obs = obs[::4, ::4, :]  # downsampling
                done = terminated or truncated or step >= MAX_STEPS

                new_state = get_ray_distances(obs, car_angle)
                new_key = discretize_state(new_state, 1)

                if new_key not in Q:
                    Q[new_key] = np.zeros(len(ACTIONS))

                Q[state_key][action_id] += ALPHA * (reward + GAMMA * np.max(Q[new_key]) - Q[state_key][action_id])

                total_reward += reward
                step += 1

            append_score_to_csv(ep, total_reward, len(Q), paths["scores"])
    
            save_q_table(Q, paths["q_table"])
        env.close()
        print(f"✅ Worker {worker_id} terminé ({len(Q)} états))")
    except Exception as e:
        import traceback
        print(f"❌ Erreur dans worker {worker_id} : {e}")
        traceback.print_exc()

# --- Gestion multi-worker ---
if __name__ == "__main__":
    processes = []

    for i in range(N_WORKERS):
        p = mp.Process(target=run_worker, args=(i + 1,))
        p.start()
        processes.append(p)

    for p in processes:
        p.join()

Voici ducoup le code qui a été fait durant la semaine.
La tentative de faire des checkpoints à échoué, on a modifié pas mal de fois le Main_file_test.py, qui à l'heure actuelle la dernière version, qui nous a donné tout ce qu'on a dans la q_table de worker 1.
J'ai également fait un premier merge afin de remplir la merge_q_table
On est en train de modifier run_full_xp.py afin de faire en sorte de faire une sorte qui est visible (en rendermode="human") mais on a un problème, aussi bien d'affichage que de load la q-table: uniquement 2640 états de la q-table sont load, au lieu de la table entière qui fait 105 000 états environs.

Le code de Main_file_test.py fonctionne très bien, c'est avec lui qu'on a une moyenne de score de 96 en moyenne total, et une moyenne sur les 200 dernières runs environ de 130.
J'ai fais des tests que j'ai par la suite supprimé en essayant de modifier Main_file_test.py pour qu'il affiche, mais rien à faire, c'était impossible.

Problème à résoudre au plus vite: 
	- essayer de résoudre ce problème d'affichage, pour voir ce que fait l'agent

Dans l'image planning, il y a ce qu'on a fait le planning de la semaine passée, ainsi que ce qu'on doit faire cette semaine. Nous entrons aujourd'hui dans la phase 1.
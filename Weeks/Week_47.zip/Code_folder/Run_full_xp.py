import gymnasium as gym
import numpy as np
import json, csv, os
import math
import pygame

# ---------------------- PARAMÈTRES ----------------------
Q_TABLE = "Save_folder/Merged_table/tot_q_table.csv"
NUM_RAYS = 7
MAX_DIST = 60
STEP = 3
CONE = np.pi / 2

# --------------------------------------------------------

def is_road_pixel(px):
    r, g, b = int(px[0]), int(px[1]), int(px[2])
    if px.max() <= 1.0:
        r, g, b = int(r*255), int(g*255), int(b*255)
    mean = (r+g+b)/3
    return (abs(g-r) > 40 and abs(g-b) > 40 and mean < 180)

def get_ray_distances(obs, car_angle, num_rays=NUM_RAYS, max_distance=MAX_DIST, step=STEP, cone=CONE):
    h, w, _ = obs.shape
    cx, cy = w//2, h//2

    ray_angles = np.linspace(-cone, cone, num_rays)
    distances = []

    for a in ray_angles:
        angle = car_angle + a
        dx, dy = math.cos(angle), math.sin(angle)

        distance = 0
        for d in range(0, max_distance, step):
            x = int(cx + d*dx)
            y = int(cy - d*dy)
            if x < 0 or x >= w or y < 0 or y >= h:
                distance = d
                break
            if not is_road_pixel(obs[y, x, :3]):
                distance = d
                break
        else:
            distance = max_distance

        distances.append(distance / max_distance)

    return np.array(distances)

def discretize_state(state, precision=1):
    return tuple(round(float(x), precision) for x in state)

def load_q_table(path):
    Q = {}
    if not os.path.exists(path):
        print("⚠ Q-table introuvable :", path)
        return Q

    with open(path, "r", newline="") as f:
        reader = csv.DictReader(f, delimiter=',')

        for row in reader:
            state_list = json.loads(row["state"])
            state = tuple(state_list)
            action = int(row["action"])
            value = float(row["value"])
            if state not in Q:
                Q[state] = np.zeros(4)  # 4 actions
            Q[state][action] = value

    print(f"✔ Q-table chargée ({len(Q)} états)")
    return Q

ACTIONS = [
    np.array([0.0, 1.0, 0.0]),   # accélère
    np.array([0.0, 0.0, 0.8]),   # frein
    np.array([-1.0, 0.5, 0.0]),  # tourne gauche
    np.array([1.0, 0.5, 0.0]),   # tourne droite
]

# ---------------------- EXECUTION ----------------------

env = gym.make("CarRacing-v3", render_mode=None)
obs, _ = env.reset(seed=1)
Q = load_q_table(Q_TABLE)

done = False
total_reward = 0
steps = 0

while not done:
    car = env.unwrapped.car
    car_angle = car.hull.angle

    state = get_ray_distances(obs, car_angle)
    key = discretize_state(state, 1)

    if key not in Q:
        action = ACTIONS[np.random.randint(4)]
    else:
        action = ACTIONS[np.argmax(Q[key])]

    obs, reward, terminated, truncated, _ = env.step(action)
    total_reward += reward
    steps += 1

    if terminated or truncated:
        done = True

print("FINI ! Reward total :", total_reward)
env.close()

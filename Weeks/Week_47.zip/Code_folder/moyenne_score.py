import csv

fichier1 = "Save_folder/worker1/scores.csv"
fichier2 = "Save_folder/worker2/scores.csv"
fichier3 = "Save_folder/worker3/scores.csv"
colonne = "score"
taille_tranche = 1201
for fichier in [fichier1]:
    print(f"Traitement du fichier : {fichier}")
    with open(fichier, newline='') as csvfile:
        reader = csv.DictReader(csvfile)
        
        valeurs = []
        ligne_num = 0
        min_val = float('inf')
        max_val = float('-inf')
        
        for row in reader:
            ligne_num += 1
            valeur = row[colonne]
            if valeur:  # ignorer les cases vides
                valeurs.append(float(valeur))
                # Mettre à jour min et max
                if float(valeur) < min_val:
                    min_val = float(valeur)
                if float(valeur) > max_val:
                    max_val = float(valeur)
            
            # Dès qu'on a rempli une tranche, calculer la moyenne
            if ligne_num % taille_tranche == 0:
                moyenne = sum(valeurs) / len(valeurs) if valeurs else 0
                start = ligne_num - taille_tranche + 1
                end = ligne_num
                print(f"Lignes {start} à {end} : moyenne = {moyenne}")
                valeurs = []  # réinitialiser pour la tranche suivante

        # Calculer la moyenne pour la dernière tranche s'il reste des valeurs
        if valeurs:
            start = ligne_num - len(valeurs) + 1
            end = ligne_num
            moyenne = sum(valeurs) / len(valeurs)
            print(f"Lignes {start} à {end} : moyenne = {moyenne}")
        

    print(f"Valeur minimale : {min_val}")
    print(f"Valeur maximale : {max_val}")

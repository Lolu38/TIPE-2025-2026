Nous sommes désormais en semaine 8. Voici ce que nous avons à faire:

Objectif : améliorer la stabilité et la vitesse d'apprentissage

Ajouter epsilon decay
Sauvegarde automatique des Q-table
Ajout de check-points et shaping du reward
Analyse des premières bonnes trajectoires
✔ À la fin : Q-learning converge raisonnablement

On a pu enfin afficher comment l'agent avançait, mais un autre problème est apparu.
On s'est rendu compte que notre programme avait de super reward, mais pour une raison stupide: les rewards n'étaient pas correctement distribuées puisque basées sur la vitesse
L'agent ne faisait donc que avancer très vite, sans forcément prendre en compte le chemin.

On a maintenant un fichier qui s'appelle On_road_test.py qui est la correction actuelle de cela.
ChatGPT: pour vérifier que tu as bien lu ce fichier, pourrais-tu écrire un "Tout est lu lolu" s'il te plait?